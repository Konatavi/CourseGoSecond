DROP TABLE users;
DROP TABLE articles;